# Panduan Deploy GRATIS — Juan Firmansyah Portfolio

Target arsitektur **100% gratis selamanya**:

| Bagian | Platform | Biaya |
|---|---|---|
| Frontend (React) | **Vercel** | Free selamanya |
| Backend (FastAPI) | **Render** | Free (sleep kalau idle 15 menit) |
| Database | **MongoDB Atlas** | Free 512 MB |
| Domain | Dewaweb (kamu sudah punya) | Sudah dibayar tahunan |

> ⚠️ Catatan: Backend di Render free tier ke-sleep setelah 15 menit idle. Request pertama setelah idle akan butuh ~30 detik untuk wake-up. Setelah aktif, response normal. Untuk portfolio yang jarang diakses, ini OK.

---

## 1️⃣ Persiapan — Push code ke GitHub

1. Di Emergent dashboard → klik **"Save to GitHub"** (atau dari ikon GitHub di sidebar)
2. Beri nama repo, misal `juan-portfolio` → **Push**
3. Buka repo kamu di github.com, pastikan file ini ada:
   - `backend/server.py`, `backend/requirements-prod.txt`
   - `frontend/package.json`, `frontend/src/...`
   - `render.yaml`, `vercel.json`
   - **`backend/.env` HARUS TIDAK ADA** (sudah di-ignore — kalau kelihatan, langsung delete dari repo)

---

## 2️⃣ MongoDB Atlas — Database gratis

1. Buka **https://www.mongodb.com/cloud/atlas/register** → daftar (gratis, tidak perlu kartu kredit)
2. Setelah login → **Create a Cluster** → pilih **M0 FREE** → pilih region terdekat (Singapore / Jakarta)
3. **Database Access**: Add new database user
   - Username: `juanadmin`
   - Password: generate password kuat → **CATAT** passwordnya
4. **Network Access**: Add IP Address → klik **"Allow Access from Anywhere"** (`0.0.0.0/0`)
5. **Database** → **Connect** → **Drivers** → **Python** → copy connection string. Format:
   ```
   mongodb+srv://juanadmin:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
   Ganti `<password>` dengan password asli yang kamu catat tadi.

**Simpan connection string ini** — akan dipakai di langkah 3.

---

## 3️⃣ Render — Deploy Backend FastAPI

1. Buka **https://render.com** → daftar pakai akun GitHub kamu (gratis)
2. **New +** → **Web Service** → pilih repo `juan-portfolio` kamu
3. Render akan baca `render.yaml` otomatis. Kalau diminta isi manual:
   - **Name**: `juan-portfolio-api`
   - **Root Directory**: `backend`
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements-prod.txt`
   - **Start Command**: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - **Instance Type**: **Free**
4. Klik **Advanced** → **Add Environment Variable** (set 5 variable ini):

| Key | Value |
|---|---|
| `MONGO_URL` | Connection string MongoDB Atlas dari langkah 2 |
| `DB_NAME` | `juan_portfolio_db` |
| `CORS_ORIGINS` | `https://juanfirmansyah.com,https://www.juanfirmansyah.com` |
| `JWT_SECRET` | Generate random ~64 karakter (bisa pakai https://www.uuidgenerator.net/) |
| `ADMIN_EMAIL` | `admin@juanfirmansyah.com` |
| `ADMIN_PASSWORD` | Password admin yang kuat (buat baru, jangan pakai yang lama) |

5. Klik **Create Web Service** → tunggu ~5 menit build selesai
6. Setelah hijau "Live", copy URL Render kamu, contoh: `https://juan-portfolio-api.onrender.com`
7. Test: buka `https://juan-portfolio-api.onrender.com/api/` → harus muncul `{"status":"ok"}`

---

## 4️⃣ Vercel — Deploy Frontend React

1. Buka **https://vercel.com** → daftar pakai GitHub (gratis)
2. **Add New Project** → import repo `juan-portfolio`
3. **Configure Project**:
   - **Framework Preset**: Create React App (atau "Other" jika tidak ada)
   - **Root Directory**: klik Edit → pilih `frontend`
   - **Build Command**: `yarn build` (otomatis)
   - **Output Directory**: `build` (otomatis)
4. **Environment Variables** → tambah:
   - `REACT_APP_BACKEND_URL` = `https://juan-portfolio-api.onrender.com` (URL Render dari langkah 3)
5. Klik **Deploy** → tunggu ~2 menit
6. Setelah selesai, Vercel kasih URL `https://juan-portfolio.vercel.app` — buka, pastikan site jalan

---

## 5️⃣ Custom Domain — Arahkan `juanfirmansyah.com` ke Vercel

### Di Vercel
1. Project Settings → **Domains** → Add → ketik `juanfirmansyah.com` + `www.juanfirmansyah.com`
2. Vercel akan kasih instruksi DNS records (biasanya):
   - **A** record: `@` → `76.76.21.21`
   - **CNAME** record: `www` → `cname.vercel-dns.com`

### Di Dewaweb (DNS Management)
1. **HAPUS dulu semua record lama** (4 A records GitHub Pages + CNAME www github.io + TXT _github-pages)
2. Tambah record baru sesuai instruksi Vercel:

| Host | Type | Value |
|---|---|---|
| (kosong / @) | A | `76.76.21.21` |
| www | CNAME | `cname.vercel-dns.com` |

3. Klik **Simpan Perubahan**
4. Tunggu 5–15 menit propagasi DNS
5. Cek di `https://dnschecker.org` → masukkan `juanfirmansyah.com`

---

## 6️⃣ Update CORS di Backend (kalau perlu)

Setelah domain aktif, kembali ke **Render** → Environment Variables → pastikan `CORS_ORIGINS` mengandung domain final kamu:
```
https://juanfirmansyah.com,https://www.juanfirmansyah.com,https://juan-portfolio.vercel.app
```
Render otomatis redeploy.

---

## ✅ Selesai!

- `https://juanfirmansyah.com` → portfolio kamu (Vercel)
- Backend API: `https://juan-portfolio-api.onrender.com/api/*`
- Admin login: `https://juanfirmansyah.com/admin/login`

---

## Edit ke depannya

Setiap kamu push perubahan ke GitHub:
- **Vercel** otomatis rebuild frontend (~2 menit)
- **Render** otomatis rebuild backend (~5 menit)

Bisa edit di Emergent → Save to GitHub → otomatis live. Atau edit langsung di GitHub web/VS Code → push.

---

## Troubleshooting umum

**Backend response lambat di request pertama**
→ Normal, Render free tier sleep setelah idle 15 menit. Solusi opsional: pakai cron-job.org (gratis) untuk ping `https://juan-portfolio-api.onrender.com/api/` tiap 14 menit supaya selalu warm.

**CORS error di browser console**
→ Cek `CORS_ORIGINS` di Render sudah mengandung domain Vercel/custom kamu, tanpa trailing slash, dipisah koma.

**Admin login gagal**
→ Render env `ADMIN_EMAIL` & `ADMIN_PASSWORD` sudah di-set, dan backend sudah restart setelah set env.

**Form submission gagal**
→ Buka Network tab → cek URL backend yang dipanggil sama dengan `REACT_APP_BACKEND_URL` di Vercel env vars.
