from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import uuid
import logging
import bcrypt
import jwt as pyjwt
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Literal

from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr, ConfigDict


# MongoDB
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI(title="Juan Firmansyah Portfolio API")
api_router = APIRouter(prefix="/api")

JWT_ALGO = "HS256"


# --------- Models ---------
class ContactCreate(BaseModel):
    name: str
    email: EmailStr
    company: Optional[str] = None
    inquiry_type: Literal["consulting", "executive_role", "speaking", "general"] = "general"
    message: str


class ContactOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    company: Optional[str] = None
    inquiry_type: str
    message: str
    created_at: str


class CommentCreate(BaseModel):
    post_id: str
    name: str
    email: EmailStr
    content: str


class CommentOut(BaseModel):
    id: str
    post_id: str
    name: str
    content: str
    created_at: str
    approved: bool


class AdminCommentOut(CommentOut):
    email: EmailStr


class LoginInput(BaseModel):
    email: EmailStr
    password: str


class LoginResponse(BaseModel):
    token: str
    email: str
    role: str


class ModerationInput(BaseModel):
    approved: bool


# --------- Auth helpers ---------
def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def verify_password(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())


def create_token(email: str, role: str) -> str:
    payload = {
        "sub": email,
        "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(hours=24),
    }
    return pyjwt.encode(payload, os.environ["JWT_SECRET"], algorithm=JWT_ALGO)


async def require_admin(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1]
    try:
        payload = pyjwt.decode(token, os.environ["JWT_SECRET"], algorithms=[JWT_ALGO])
    except pyjwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except pyjwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Forbidden")
    return payload


# --------- Endpoints ---------
@api_router.get("/")
async def root():
    return {"status": "ok", "service": "juan-portfolio"}


@api_router.post("/contact", response_model=ContactOut)
async def create_contact(payload: ContactCreate):
    doc = {
        "id": str(uuid.uuid4()),
        "name": payload.name.strip(),
        "email": payload.email.lower(),
        "company": (payload.company or "").strip() or None,
        "inquiry_type": payload.inquiry_type,
        "message": payload.message.strip(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.contacts.insert_one(doc)
    return ContactOut(**doc)


@api_router.post("/comments", response_model=CommentOut)
async def create_comment(payload: CommentCreate):
    doc = {
        "id": str(uuid.uuid4()),
        "post_id": payload.post_id,
        "name": payload.name.strip(),
        "email": payload.email.lower(),
        "content": payload.content.strip(),
        "approved": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.comments.insert_one(doc)
    return CommentOut(
        id=doc["id"],
        post_id=doc["post_id"],
        name=doc["name"],
        content=doc["content"],
        created_at=doc["created_at"],
        approved=doc["approved"],
    )


@api_router.get("/comments/{post_id}", response_model=List[CommentOut])
async def list_approved_comments(post_id: str):
    cursor = db.comments.find({"post_id": post_id, "approved": True}, {"_id": 0, "email": 0}).sort("created_at", -1)
    items = await cursor.to_list(500)
    return [CommentOut(**i) for i in items]


@api_router.post("/auth/login", response_model=LoginResponse)
async def login(payload: LoginInput):
    user = await db.users.find_one({"email": payload.email.lower()})
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(user["email"], user.get("role", "admin"))
    return LoginResponse(token=token, email=user["email"], role=user.get("role", "admin"))


@api_router.get("/auth/me")
async def me(admin=Depends(require_admin)):
    return {"email": admin["sub"], "role": admin["role"]}


@api_router.get("/admin/comments", response_model=List[AdminCommentOut])
async def admin_list_comments(status: Optional[str] = None, admin=Depends(require_admin)):
    query: dict = {}
    if status == "pending":
        query["approved"] = False
    elif status == "approved":
        query["approved"] = True
    cursor = db.comments.find(query, {"_id": 0}).sort("created_at", -1)
    items = await cursor.to_list(1000)
    return [AdminCommentOut(**i) for i in items]


@api_router.patch("/admin/comments/{comment_id}", response_model=AdminCommentOut)
async def admin_moderate_comment(comment_id: str, payload: ModerationInput, admin=Depends(require_admin)):
    result = await db.comments.find_one_and_update(
        {"id": comment_id},
        {"$set": {"approved": payload.approved}},
        return_document=True,
        projection={"_id": 0},
    )
    if not result:
        raise HTTPException(status_code=404, detail="Comment not found")
    return AdminCommentOut(**result)


@api_router.delete("/admin/comments/{comment_id}")
async def admin_delete_comment(comment_id: str, admin=Depends(require_admin)):
    result = await db.comments.delete_one({"id": comment_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Comment not found")
    return {"ok": True}


@api_router.get("/admin/contacts", response_model=List[ContactOut])
async def admin_list_contacts(admin=Depends(require_admin)):
    cursor = db.contacts.find({}, {"_id": 0}).sort("created_at", -1)
    items = await cursor.to_list(1000)
    return [ContactOut(**i) for i in items]


# Register router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@app.on_event("startup")
async def on_startup():
    # Seed admin
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@example.com").lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "admin123")
    existing = await db.users.find_one({"email": admin_email})
    if not existing:
        await db.users.insert_one({
            "email": admin_email,
            "password_hash": hash_password(admin_password),
            "role": "admin",
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        logger.info(f"Seeded admin: {admin_email}")
    elif not verify_password(admin_password, existing["password_hash"]):
        await db.users.update_one(
            {"email": admin_email},
            {"$set": {"password_hash": hash_password(admin_password)}},
        )
        logger.info("Admin password updated from .env")


@app.on_event("shutdown")
async def on_shutdown():
    client.close()
