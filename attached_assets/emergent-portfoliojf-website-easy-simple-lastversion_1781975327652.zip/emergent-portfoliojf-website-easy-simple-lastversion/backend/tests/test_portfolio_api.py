"""End-to-end backend tests for Juan Firmansyah Portfolio API.

Covers:
- Health check (/api/)
- Contact form (POST /api/contact)
- Public comments (POST /api/comments, GET /api/comments/{post_id})
- Admin auth (POST /api/auth/login, GET /api/auth/me)
- Admin comment moderation (GET, PATCH, DELETE /api/admin/comments)
- Admin contacts list (GET /api/admin/contacts)
- 401 on protected endpoints without token
"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://revenue-leader.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@juanfirmansyah.com"
ADMIN_PASSWORD = "Juan2024!"


@pytest.fixture(scope="session")
def api_client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def admin_token(api_client):
    r = api_client.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    data = r.json()
    assert "token" in data and isinstance(data["token"], str) and len(data["token"]) > 0
    assert data["email"].lower() == ADMIN_EMAIL.lower()
    assert data["role"] == "admin"
    return data["token"]


@pytest.fixture(scope="session")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


# ---------- Health ----------
class TestHealth:
    def test_root(self, api_client):
        r = api_client.get(f"{API}/")
        assert r.status_code == 200
        assert r.json().get("status") == "ok"


# ---------- Contact ----------
class TestContact:
    def test_create_contact(self, api_client, admin_headers):
        payload = {
            "name": "TEST_Jane Doe",
            "email": "TEST_jane@example.com",
            "company": "TEST Acme",
            "inquiry_type": "consulting",
            "message": "Interested in your services.",
        }
        r = api_client.post(f"{API}/contact", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["name"] == "TEST_Jane Doe"
        assert data["email"] == "test_jane@example.com"
        assert data["company"] == "TEST Acme"
        assert data["inquiry_type"] == "consulting"
        assert "id" in data and "created_at" in data
        # Verify persistence via admin endpoint
        r2 = requests.get(f"{API}/admin/contacts", headers=admin_headers)
        assert r2.status_code == 200
        emails = [c["email"] for c in r2.json()]
        assert "test_jane@example.com" in emails

    def test_contact_invalid_email(self, api_client):
        r = api_client.post(f"{API}/contact", json={
            "name": "X", "email": "not-an-email", "message": "hi"
        })
        assert r.status_code == 422


# ---------- Comments (public) ----------
class TestPublicComments:
    POST_ID = "icp-is-everything"

    def test_create_comment_starts_unapproved(self, api_client):
        unique = f"TEST_{uuid.uuid4().hex[:8]}"
        r = api_client.post(f"{API}/comments", json={
            "post_id": self.POST_ID,
            "name": f"TEST_User_{unique}",
            "email": f"{unique}@example.com",
            "content": f"This is a test comment {unique}",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["approved"] is False
        assert data["post_id"] == self.POST_ID
        assert "email" not in data  # email not exposed publicly
        pytest.shared_comment_id = data["id"]
        pytest.shared_comment_name = data["name"]

    def test_public_list_excludes_unapproved(self, api_client):
        r = api_client.get(f"{API}/comments/{self.POST_ID}")
        assert r.status_code == 200
        items = r.json()
        names = [c["name"] for c in items]
        assert pytest.shared_comment_name not in names
        for c in items:
            assert c["approved"] is True
            assert "email" not in c


# ---------- Auth ----------
class TestAuth:
    def test_login_wrong_password(self, api_client):
        r = api_client.post(f"{API}/auth/login", json={
            "email": ADMIN_EMAIL, "password": "WrongPass!!"
        })
        assert r.status_code == 401

    def test_login_success_returns_token(self, admin_token):
        assert admin_token

    def test_me_with_token(self, admin_headers):
        r = requests.get(f"{API}/auth/me", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert data["email"].lower() == ADMIN_EMAIL.lower()
        assert data["role"] == "admin"


# ---------- Admin Protected ----------
class TestAdminProtected:
    def test_admin_comments_no_token(self, api_client):
        r = api_client.get(f"{API}/admin/comments")
        assert r.status_code == 401

    def test_admin_contacts_no_token(self, api_client):
        r = api_client.get(f"{API}/admin/contacts")
        assert r.status_code == 401

    def test_admin_invalid_token(self, api_client):
        r = requests.get(f"{API}/admin/comments", headers={"Authorization": "Bearer invalid.token.here"})
        assert r.status_code == 401


# ---------- Moderation Flow ----------
class TestModeration:
    def test_approve_pending_comment_appears_publicly(self, admin_headers):
        # List pending
        r = requests.get(f"{API}/admin/comments?status=pending", headers=admin_headers)
        assert r.status_code == 200
        pending = r.json()
        target = next((c for c in pending if c["id"] == pytest.shared_comment_id), None)
        assert target is not None, "Newly created comment should be pending"
        assert target["approved"] is False
        assert "email" in target  # admin should see email

        # Approve
        r2 = requests.patch(
            f"{API}/admin/comments/{pytest.shared_comment_id}",
            json={"approved": True}, headers=admin_headers,
        )
        assert r2.status_code == 200, r2.text
        assert r2.json()["approved"] is True

        # Should now show in public list
        r3 = requests.get(f"{API}/comments/{TestPublicComments.POST_ID}")
        assert r3.status_code == 200
        names = [c["name"] for c in r3.json()]
        assert pytest.shared_comment_name in names

    def test_delete_comment_cleanup(self, admin_headers):
        r = requests.delete(
            f"{API}/admin/comments/{pytest.shared_comment_id}", headers=admin_headers,
        )
        assert r.status_code == 200
        # Re-delete -> 404
        r2 = requests.delete(
            f"{API}/admin/comments/{pytest.shared_comment_id}", headers=admin_headers,
        )
        assert r2.status_code == 404

    def test_patch_nonexistent_comment(self, admin_headers):
        r = requests.patch(
            f"{API}/admin/comments/nonexistent-id-xyz",
            json={"approved": True}, headers=admin_headers,
        )
        assert r.status_code == 404
