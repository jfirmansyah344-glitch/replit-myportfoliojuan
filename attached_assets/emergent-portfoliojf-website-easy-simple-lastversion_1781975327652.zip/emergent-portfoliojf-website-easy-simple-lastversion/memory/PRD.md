# Juan Firmansyah — Executive Portfolio · PRD

## Original problem
Premium, minimalist, multi-page executive portfolio for a Commercial Growth & Business Development leader (Juan Firmansyah). 10+ years across FMCG, Healthcare, HRTech, Social Enterprise, Professional Services. SEO-aware, with Light/Dark/System theme toggle on every page. Three-column footer with Hire Juan + Access Insights CTAs. Multi-page architecture: Home, Work (list + case-study detail), Expertise (services + digital store), Insights (blog + video + moderated comments), Recommendations (3 categories), About, Contact.

## Personas
- Founders/CEOs/Boards evaluating Juan for a CGO/Commercial role
- Scale-up operators looking for fractional commercial leadership
- Operators/program leaders interested in his content (e-books, templates, seminars)
- Conference / coaching organisers

## Tech architecture
- **Frontend**: React 19 + React Router 7 + Tailwind + shadcn/ui + sonner + react-fast-marquee + next-themes-style custom ThemeProvider.
- **Backend**: FastAPI + Motor (MongoDB) + bcrypt + PyJWT for admin auth.
- **Storage**: MongoDB collections — `users` (admin), `contacts`, `comments`.

## Implemented (Dec 2025)
- Multi-page site: Home, Work, Work/:id, Expertise, Insights, Insights/:id, Recommendations, About, Contact, Admin login, Admin Comments, 404
- Light/Dark/System theme toggle in top-right header (persists in localStorage)
- 3-column footer on every page (Identity + socials + Hire Juan / Access Insights CTAs · Expertise · Quick Links)
- 3 full case studies with 6-section structure (snapshot/problem/approach/execution/results/takeaway) + illustrative growth chart placeholder
- Digital store with 4 products and 3 services, with CTA → /contact (showcase only, no payments)
- Insights blog with YouTube embeds + MODERATED comment section
- Admin dashboard: pending/approved/all tabs, approve/unapprove/delete
- Contact form (consulting / executive_role / speaking / general) → persisted to MongoDB
- SEO meta tags, Outfit + Plus Jakarta Sans fonts, accessible data-testids throughout

## Test credentials
- Admin: `admin@juanfirmansyah.com` / `Juan2024!`

## Backlog (P1/P2)
- **P1**: Replace illustrative chart with real evidence images per case study; swap YouTube IDs for Juan's actual talks; swap LinkedIn/social URLs
- **P1**: Add Stripe checkout for digital store (currently 'Buy' → /contact)
- **P2**: Spam protection on comments (hCaptcha or honeypot), brute-force lockout on admin login
- **P2**: Newsletter capture in footer + RSS for insights
- **P2**: Tighten CORS to explicit production origins; move admin token to httpOnly cookies
- **P2**: Pagination/search on Insights list and admin queue
- **P2**: Open Graph / Twitter card image asset
