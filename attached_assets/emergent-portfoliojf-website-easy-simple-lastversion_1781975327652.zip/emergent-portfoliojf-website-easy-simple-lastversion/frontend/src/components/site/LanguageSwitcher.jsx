import { useEffect, useState } from "react";
import { useLang } from "./LanguageProvider";
import { cn } from "@/lib/utils";

export default function LanguageSwitcher() {
  const { lang, setLang } = useLang();
  const [pulse, setPulse] = useState(false);

  // On first visit ever, draw the eye with a one-time pulse animation
  useEffect(() => {
    if (typeof window === "undefined") return;
    const seen = localStorage.getItem("jf_lang_seen");
    if (!seen) {
      setPulse(true);
      localStorage.setItem("jf_lang_seen", "1");
      const id = setTimeout(() => setPulse(false), 2400);
      return () => clearTimeout(id);
    }
  }, []);

  return (
    <div
      role="group"
      aria-label="Language"
      data-testid="language-switcher"
      className={cn(
        "relative inline-flex items-center h-9 rounded-full border border-border p-0.5 bg-background",
        pulse && "ring-2 ring-emerald-500/60 animate-pulse"
      )}
    >
      <button
        type="button"
        onClick={() => setLang("en")}
        data-testid="lang-en"
        aria-pressed={lang === "en"}
        className={cn(
          "px-3 h-8 rounded-full text-xs font-semibold tracking-wider transition-all",
          lang === "en"
            ? "bg-foreground text-background"
            : "text-muted-foreground hover:text-foreground"
        )}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => setLang("id")}
        data-testid="lang-id"
        aria-pressed={lang === "id"}
        className={cn(
          "px-3 h-8 rounded-full text-xs font-semibold tracking-wider transition-all",
          lang === "id"
            ? "bg-foreground text-background"
            : "text-muted-foreground hover:text-foreground"
        )}
      >
        ID
      </button>
    </div>
  );
}
