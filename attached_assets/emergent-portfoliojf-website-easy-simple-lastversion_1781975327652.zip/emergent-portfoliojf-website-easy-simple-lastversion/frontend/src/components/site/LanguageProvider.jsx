import { createContext, useContext, useEffect, useState } from "react";

const LangContext = createContext({ lang: "en", setLang: () => {} });

function detectLang() {
  if (typeof window === "undefined") return "en";
  const stored = localStorage.getItem("jf_lang");
  if (stored === "en" || stored === "id") return stored;
  const nav = (navigator.language || "en").toLowerCase();
  return nav.startsWith("id") ? "id" : "en";
}

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState(detectLang);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = (l) => {
    if (l !== "en" && l !== "id") return;
    localStorage.setItem("jf_lang", l);
    setLangState(l);
  };

  return <LangContext.Provider value={{ lang, setLang }}>{children}</LangContext.Provider>;
}

export const useLang = () => useContext(LangContext);

// Helper: localize a value. Works with strings and {en, id} objects.
export function localize(value, lang) {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number") return value;
  if (typeof value === "object" && (value.en || value.id)) {
    return value[lang] || value.en || value.id || "";
  }
  return value;
}

// Hook returning a stable t() function bound to current language.
export function useT() {
  const { lang } = useLang();
  const t = (v) => localize(v, lang);
  return { t, lang };
}
