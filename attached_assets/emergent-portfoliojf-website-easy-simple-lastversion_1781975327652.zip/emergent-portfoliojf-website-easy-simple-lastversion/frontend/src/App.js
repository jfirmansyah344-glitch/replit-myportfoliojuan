import { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { Toaster } from "sonner";
import { ThemeProvider } from "@/components/site/ThemeProvider";
import { LanguageProvider } from "@/components/site/LanguageProvider";
import Layout from "@/components/site/Layout";

import HomePage from "@/pages/HomePage";
import WorkPage from "@/pages/WorkPage";
import WorkDetailPage from "@/pages/WorkDetailPage";
import ExpertisePage from "@/pages/ExpertisePage";
import InsightsPage from "@/pages/InsightsPage";
import InsightDetailPage from "@/pages/InsightDetailPage";
import RecommendationsPage from "@/pages/RecommendationsPage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import AdminLoginPage from "@/pages/AdminLoginPage";
import AdminCommentsPage from "@/pages/AdminCommentsPage";
import NotFoundPage from "@/pages/NotFoundPage";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo({ top: 0, behavior: "instant" }); }, [pathname]);
  return null;
}

function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="App">
          <BrowserRouter>
            <ScrollToTop />
            <Layout>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/work" element={<WorkPage />} />
                <Route path="/work/:id" element={<WorkDetailPage />} />
                <Route path="/expertise" element={<ExpertisePage />} />
                <Route path="/insights" element={<InsightsPage />} />
                <Route path="/insights/:id" element={<InsightDetailPage />} />
                <Route path="/recommendations" element={<RecommendationsPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/admin/login" element={<AdminLoginPage />} />
                <Route path="/admin/comments" element={<AdminCommentsPage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Layout>
            <Toaster position="bottom-right" richColors closeButton />
          </BrowserRouter>
        </div>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;
