import { useState } from "react";
import { useNavigate, Link, Navigate } from "react-router-dom";
import { adminLogin, isAdminAuthed } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  if (isAdminAuthed()) return <Navigate to="/admin/comments" replace />;

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await adminLogin(form.email, form.password);
      toast.success("Welcome back.");
      navigate("/admin/comments");
    } catch (err) {
      toast.error("Invalid credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div data-testid="admin-login-page" className="container-x section-y min-h-[70vh] flex items-center justify-center">
      <form onSubmit={onSubmit} className="w-full max-w-md border border-border rounded-lg p-8 grid gap-5" data-testid="admin-login-form">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="mt-3 font-display text-3xl tracking-tight font-medium">Sign in</h1>
          <p className="mt-2 text-sm text-muted-foreground">Moderate the insights comment section.</p>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" data-testid="admin-email-input" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="admin@…" />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" data-testid="admin-password-input" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
        </div>
        <Button type="submit" disabled={loading} className="rounded-full" data-testid="admin-login-submit">
          {loading ? "Signing in…" : "Sign in"}
        </Button>
        <Link to="/" className="text-xs text-muted-foreground hover:text-foreground text-center">Back to site</Link>
      </form>
    </div>
  );
}
