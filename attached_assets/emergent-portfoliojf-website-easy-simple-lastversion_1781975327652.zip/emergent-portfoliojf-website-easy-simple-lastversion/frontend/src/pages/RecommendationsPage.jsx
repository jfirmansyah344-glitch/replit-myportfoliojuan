import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { RECOMMENDATIONS, RECOMMENDATIONS_CATS, UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

const categories = Object.keys(RECOMMENDATIONS);

export default function RecommendationsPage() {
  const { t } = useT();
  return (
    <div data-testid="recommendations-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="eyebrow">{t(UI.sections.recsHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.recsHeader.h1)}
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">{t(UI.sections.recsHeader.sub)}</p>
        </div>
      </header>

      <Tabs defaultValue={categories[0]} className="mt-16">
        <TabsList className="grid grid-cols-1 sm:grid-cols-3 h-auto bg-transparent p-0 gap-2" data-testid="recommendations-tabs">
          {categories.map((c) => (
            <TabsTrigger key={c} value={c} data-testid={`rec-tab-${c.toLowerCase().replace(/\s/g, "-")}`}
              className="rounded-full border border-border data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:border-foreground h-11 px-6 text-sm font-medium">
              {t(RECOMMENDATIONS_CATS[c])}
            </TabsTrigger>
          ))}
        </TabsList>

        {categories.map((c) => (
          <TabsContent key={c} value={c} className="mt-10">
            <div className="grid md:grid-cols-2 gap-6">
              {RECOMMENDATIONS[c].map((r, i) => (
                <figure key={i} className="border border-border rounded-lg p-7 bg-card" data-testid={`rec-${c.toLowerCase().replace(/\s/g, "-")}-${i}`}>
                  <blockquote className="font-display text-xl sm:text-2xl tracking-tight leading-snug font-medium text-balance">
                    "{r.quote}"
                  </blockquote>
                  <figcaption className="mt-6 border-t border-border pt-4">
                    <div className="font-medium">{r.name}</div>
                    <div className="text-sm text-muted-foreground">{r.role}</div>
                  </figcaption>
                </figure>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
