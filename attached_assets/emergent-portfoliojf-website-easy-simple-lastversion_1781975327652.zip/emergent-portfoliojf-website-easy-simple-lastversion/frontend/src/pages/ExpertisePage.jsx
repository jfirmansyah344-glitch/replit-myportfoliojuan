import { Link } from "react-router-dom";
import { ArrowUpRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SERVICES, PRODUCTS, UI, GALLERY } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function ExpertisePage() {
  const { t } = useT();
  return (
    <div data-testid="expertise-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="eyebrow">{t(UI.sections.expertiseHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.expertiseHeader.h1)}
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">{t(UI.sections.expertiseHeader.sub)}</p>
        </div>
      </header>

      <section className="mt-20 grid gap-6" data-testid="services-grid">
        <div className="eyebrow">{t(UI.sections.expertiseHeader.servicesHeader)}</div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((s) => (
            <div key={s.id} id={s.id} className="border border-border rounded-lg p-7 bg-card hover:-translate-y-1 hover:shadow-md transition-all" data-testid={`service-card-${s.id}`}>
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(s.engagement)}</div>
              <h2 className="mt-3 font-display text-2xl tracking-tight font-medium">{t(s.name)}</h2>
              <p className="mt-3 text-base text-muted-foreground leading-relaxed">{t(s.summary)}</p>
              <ul className="mt-5 grid gap-2">
                {t(s.deliverables).map((d, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0" /> {d}
                  </li>
                ))}
              </ul>
              <Button asChild className="mt-6 rounded-full" data-testid={`service-cta-${s.id}`}>
                <Link to="/contact">{t(UI.cta.enquire)} <ArrowUpRight className="h-4 w-4" /></Link>
              </Button>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-24 border-t border-border pt-16" data-testid="products-section">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="eyebrow">{t(UI.sections.expertiseHeader.productsEyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl tracking-tight font-medium text-balance">
              {t(UI.sections.expertiseHeader.productsHeading)}
            </h2>
          </div>
          <p className="lg:col-span-4 text-muted-foreground text-sm">{t(UI.sections.expertiseHeader.productsSub)}</p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PRODUCTS.map((p) => (
            <div key={p.id} id={p.id} className="border border-border rounded-lg p-7 bg-card hover:-translate-y-1 hover:shadow-md transition-all" data-testid={`product-card-${p.id}`}>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(p.type)}</div>
                  <h3 className="mt-3 font-display text-2xl tracking-tight font-medium">{t(p.name)}</h3>
                </div>
                <div className="font-display text-2xl tracking-tight font-medium">{p.price}</div>
              </div>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">{t(p.summary)}</p>
              <div className="mt-6 flex items-center gap-3">
                <Button asChild className="rounded-full px-6" data-testid={`product-buy-${p.id}`}>
                  <Link to="/contact">{t(p.cta)} <ArrowUpRight className="h-4 w-4" /></Link>
                </Button>
                <Button asChild variant="ghost" className="rounded-full" data-testid={`product-details-${p.id}`}>
                  <Link to="/contact">{t(UI.cta.details)}</Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SPEAKING GALLERY */}
      <section className="mt-24 border-t border-border pt-16" data-testid="speaking-gallery">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="eyebrow">{t(UI.sections.gallery.eyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl tracking-tight font-medium text-balance">
              {t(UI.sections.gallery.heading)}
            </h2>
          </div>
          <p className="lg:col-span-4 text-muted-foreground text-sm">{t(UI.sections.gallery.sub)}</p>
        </div>
        <div className="mt-12 grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {GALLERY.map((g, i) => (
            <figure key={i} className="group border border-border rounded-lg overflow-hidden bg-card" data-testid={`gallery-item-${i}`}>
              <div className="aspect-[4/3] overflow-hidden bg-muted">
                <img src={g.src} alt={t(g.caption) || `Gallery ${i + 1}`} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <figcaption className="p-3 text-xs text-muted-foreground border-t border-border">{t(g.caption)}</figcaption>
            </figure>
          ))}
        </div>
      </section>
    </div>
  );
}
