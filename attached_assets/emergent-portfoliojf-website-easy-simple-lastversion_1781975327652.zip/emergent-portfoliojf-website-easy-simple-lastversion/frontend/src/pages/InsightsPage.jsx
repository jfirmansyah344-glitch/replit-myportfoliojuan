import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Play } from "lucide-react";
import { INSIGHTS, UI, ALL_SKILL_TAGS } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";
import { cn } from "@/lib/utils";

export default function InsightsPage() {
  const { t } = useT();
  const [activeSkill, setActiveSkill] = useState("__all__");

  // Build the list of skill tags actually present in posts (so empty facets aren't shown)
  const availableSkills = useMemo(() => {
    const set = new Set();
    INSIGHTS.forEach((p) => (p.skills || []).forEach((s) => set.add(s)));
    // preserve order of ALL_SKILL_TAGS
    return ALL_SKILL_TAGS.filter((s) => set.has(s));
  }, []);

  const filtered = useMemo(() => {
    if (activeSkill === "__all__") return INSIGHTS;
    return INSIGHTS.filter((p) => (p.skills || []).includes(activeSkill));
  }, [activeSkill]);

  const [featured, ...rest] = filtered.length > 0 ? filtered : [INSIGHTS[0]];

  return (
    <div data-testid="insights-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="eyebrow">{t(UI.sections.insightsHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.insightsHeader.h1)}
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">{t(UI.sections.insightsHeader.sub)}</p>
        </div>
      </header>

      {/* SKILL FILTER */}
      <section className="mt-12" data-testid="insights-filter">
        <div className="eyebrow mb-4">{t(UI.sections.insightsHeader.filterEyebrow)}</div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setActiveSkill("__all__")}
            data-testid="filter-all"
            className={cn(
              "text-sm px-4 py-2 rounded-full border transition-colors",
              activeSkill === "__all__"
                ? "bg-foreground text-background border-foreground"
                : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            {t(UI.sections.insightsHeader.filterAll)}
          </button>
          {availableSkills.map((skill) => (
            <button
              key={skill}
              type="button"
              onClick={() => setActiveSkill(skill)}
              data-testid={`filter-${skill.toLowerCase().replace(/\s/g, "-")}`}
              className={cn(
                "text-sm px-4 py-2 rounded-full border transition-colors",
                activeSkill === skill
                  ? "bg-foreground text-background border-foreground"
                  : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {skill}
            </button>
          ))}
        </div>
      </section>

      {/* FEATURED */}
      {featured && (
        <section className="mt-12">
          <Link to={`/insights/${featured.id}`} className="group grid lg:grid-cols-12 gap-8 items-center border border-border rounded-lg p-6 lg:p-10 hover:-translate-y-1 hover:shadow-md transition-all" data-testid={`insight-featured-${featured.id}`}>
            <div className="lg:col-span-6 aspect-[16/10] overflow-hidden rounded-md bg-muted relative">
              <img src={featured.cover} alt={t(featured.title)} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
              {featured.youtubeId && (
                <div className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-background/90 backdrop-blur px-3 py-1.5 rounded-full text-xs font-medium">
                  <Play className="h-3 w-3 fill-current" /> {t(UI.sections.insightsHeader.videoIncluded)}
                </div>
              )}
            </div>
            <div className="lg:col-span-6">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                {t(featured.category)} · {featured.date} · {t(featured.readTime)}
              </div>
              <h2 className="mt-4 font-display text-3xl sm:text-4xl tracking-tight font-medium text-balance">{t(featured.title)}</h2>
              <p className="mt-4 text-muted-foreground">{t(featured.excerpt)}</p>
              {featured.skills && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {featured.skills.map((s) => (
                    <span key={s} className="text-[11px] font-mono uppercase tracking-wider px-2 py-1 rounded-full border border-border text-muted-foreground">{s}</span>
                  ))}
                </div>
              )}
              <div className="mt-6 inline-flex items-center gap-2 font-medium">{t(UI.cta.readEssay)} <ArrowUpRight className="h-4 w-4" /></div>
            </div>
          </Link>
        </section>
      )}

      {/* LIST */}
      <section className="mt-16">
        <ul className="grid gap-2">
          {rest.map((p) => (
            <li key={p.id}>
              <Link to={`/insights/${p.id}`} className="group grid md:grid-cols-12 gap-6 py-7 border-t border-border hover:bg-muted/40 rounded-md px-2 transition-colors" data-testid={`insight-card-${p.id}`}>
                <div className="md:col-span-2 text-xs uppercase tracking-[0.18em] text-muted-foreground self-center">{p.date}</div>
                <div className="md:col-span-8">
                  <h3 className="font-display text-xl sm:text-2xl tracking-tight font-medium">{t(p.title)}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{t(p.category)} · {t(p.readTime)}</p>
                  {p.skills && (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {p.skills.map((s) => (
                        <span key={s} className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border border-border text-muted-foreground">{s}</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="md:col-span-2 text-right self-center">
                  <ArrowUpRight className="ml-auto h-5 w-5 group-hover:rotate-[12deg] transition-transform" />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
