import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function NotFoundPage() {
  const { t } = useT();
  return (
    <div className="container-x section-y min-h-[60vh] flex flex-col items-center justify-center text-center" data-testid="notfound-page">
      <div className="eyebrow">{t(UI.sections.notFound.eyebrow)}</div>
      <h1 className="mt-4 font-display text-5xl sm:text-6xl tracking-tighter font-medium">{t(UI.sections.notFound.heading)}</h1>
      <p className="mt-4 text-muted-foreground max-w-md">{t(UI.sections.notFound.copy)}</p>
      <Button asChild className="mt-8 rounded-full px-6"><Link to="/">{t(UI.cta.backHome)}</Link></Button>
    </div>
  );
}
