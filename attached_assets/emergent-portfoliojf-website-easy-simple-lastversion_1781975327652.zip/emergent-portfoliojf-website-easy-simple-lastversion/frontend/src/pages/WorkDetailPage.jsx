import { Link, useParams, Navigate } from "react-router-dom";
import { ArrowLeft, ArrowUpRight, Check, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CASE_STUDIES, SITE, UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function WorkDetailPage() {
  const { t } = useT();
  const { id } = useParams();
  const cs = CASE_STUDIES.find((c) => c.id === id);
  if (!cs) return <Navigate to="/work" replace />;

  const idx = CASE_STUDIES.findIndex((c) => c.id === id);
  const next = CASE_STUDIES[(idx + 1) % CASE_STUDIES.length];

  return (
    <article data-testid={`case-study-${cs.id}`} className="container-x section-y">
      <Link to="/work" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground" data-testid="case-back-link">
        <ArrowLeft className="h-4 w-4" /> {t(UI.cta.backToWork)}
      </Link>

      <header className="mt-10 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-9">
          <div className="eyebrow">{t(cs.industry)} · {cs.year}</div>
          <h1 className="mt-6 font-display text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-[1] font-medium text-balance">{t(cs.title)}</h1>
        </div>
      </header>

      <div className="mt-12 aspect-[16/8] overflow-hidden rounded-lg border border-border bg-muted">
        <img src={cs.cover} alt={t(cs.title)} className="h-full w-full object-cover" data-testid="case-cover-image" />
      </div>

      {/* 01 — Role */}
      <section className="mt-16 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3"><div className="eyebrow">{t(UI.case.snapshot)}</div></div>
        <div className="lg:col-span-9 grid sm:grid-cols-3 gap-8 border-t border-border pt-8">
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.case.role)}</div>
            <div className="mt-2 font-medium">{t(cs.snapshot.role)}</div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.case.scope)}</div>
            <div className="mt-2 font-medium">{t(cs.snapshot.scope)}</div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.case.kpis)}</div>
            <ul className="mt-2 grid gap-1">
              {t(cs.snapshot.kpis).map((k, i) => (<li key={i} className="font-medium">{k}</li>))}
            </ul>
          </div>
        </div>
      </section>

      {/* 02 — Problem */}
      <section className="mt-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3"><div className="eyebrow">{t(UI.case.problem)}</div></div>
        <div className="lg:col-span-9 border-t border-border pt-8">
          <p className="font-display text-2xl sm:text-3xl tracking-tight font-medium text-balance leading-snug">{t(cs.problem)}</p>
        </div>
      </section>

      {/* 03 — Approach */}
      <section className="mt-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3"><div className="eyebrow">{t(UI.case.approach)}</div></div>
        <div className="lg:col-span-9 border-t border-border pt-8">
          <p className="text-lg leading-relaxed">{t(cs.approach)}</p>
        </div>
      </section>

      {/* 04 — Execution */}
      <section className="mt-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3"><div className="eyebrow">{t(UI.case.execution)}</div></div>
        <div className="lg:col-span-9 border-t border-border pt-8 grid gap-4">
          {t(cs.execution).map((line, i) => (
            <div key={i} className="flex items-start gap-4">
              <div className="mt-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full border border-foreground/40">
                <Check className="h-3 w-3" />
              </div>
              <p className="text-base lg:text-lg leading-relaxed">{line}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 05 — Impact */}
      <section className="mt-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3">
          <div className="eyebrow">{t(UI.case.impact)}</div>
          <p className="mt-3 text-sm text-muted-foreground inline-flex items-center gap-2">
            <BarChart3 className="h-4 w-4" /> {t(UI.case.impactNote)}
          </p>
        </div>
        <div className="lg:col-span-9 border-t border-border pt-8 grid sm:grid-cols-3 gap-6" data-testid="case-results">
          {cs.results.map((r, i) => (
            <div key={i} className="border border-border rounded-lg p-6">
              <div className="font-display text-4xl lg:text-5xl tracking-tight font-medium">{r.metric}</div>
              <div className="mt-3 text-sm text-muted-foreground">{t(r.label)}</div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-12 mt-6">
          {cs.evidence && cs.evidence.length > 0 ? (
            <div className="grid gap-6">
              <div className="eyebrow">{t(UI.case.evidence)}</div>
              <div className={cs.evidence.length === 1 ? "grid grid-cols-1 gap-6" : cs.evidence.length === 2 ? "grid md:grid-cols-2 gap-6" : "grid md:grid-cols-2 lg:grid-cols-3 gap-6"}>
                {cs.evidence.map((ev, i) => (
                  <figure key={i} className="border border-border rounded-lg overflow-hidden bg-card" data-testid={`case-evidence-${i}`}>
                    <div className="aspect-[4/3] overflow-hidden bg-muted">
                      <img src={ev.src} alt={t(ev.caption) || `Evidence ${i + 1}`} className="h-full w-full object-cover" loading="lazy" />
                    </div>
                    {ev.caption && <figcaption className="p-4 text-sm text-muted-foreground border-t border-border">{t(ev.caption)}</figcaption>}
                  </figure>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-dashed border-border p-6 bg-muted/40">
              <div className="eyebrow mb-4">{t(UI.case.evidenceFallback)}</div>
              <div className="h-40 flex items-end gap-3">
                {[42, 55, 60, 72, 85, 96, 112, 130, 148].map((v, i) => (
                  <div key={i} className="flex-1 bg-foreground/80 dark:bg-foreground rounded-t" style={{ height: `${v}%` }} />
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 06 — Takeaway */}
      <section className="mt-20 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-3"><div className="eyebrow">{t(UI.case.takeaway)}</div></div>
        <div className="lg:col-span-9 border-t border-border pt-8">
          <blockquote className="font-display text-3xl sm:text-4xl lg:text-5xl tracking-tight leading-tight font-medium text-balance">
            "{t(cs.takeaway)}"
          </blockquote>
          <p className="mt-4 text-sm uppercase tracking-[0.18em] text-muted-foreground">— {SITE.name}</p>
        </div>
      </section>

      <div className="mt-24 border-t border-border pt-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <Button asChild variant="outline" className="rounded-full" data-testid="case-cta-contact">
          <Link to="/contact">{t(UI.cta.enrol)} <ArrowUpRight className="h-4 w-4" /></Link>
        </Button>
        <Link to={`/work/${next.id}`} className="group inline-flex items-center gap-3" data-testid="case-next-link">
          <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.cta.nextCase)}</span>
          <span className="font-display text-xl tracking-tight font-medium link-underline">{t(next.title)}</span>
          <ArrowUpRight className="h-5 w-5 group-hover:rotate-[12deg] transition-transform" />
        </Link>
      </div>
    </article>
  );
}
