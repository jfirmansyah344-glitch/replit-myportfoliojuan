import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowUpRight } from "lucide-react";
import { SITE, INDUSTRIES, TIMELINE, UI, PRINCIPLES, ABOUT_NARRATIVE, CORE_SKILLS } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function AboutPage() {
  const { t } = useT();
  return (
    <div data-testid="about-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
        <div className="lg:col-span-7">
          <div className="eyebrow">{t(UI.sections.aboutHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.aboutHeader.h1)}
          </h1>
          <div className="mt-10 grid gap-6 text-lg leading-relaxed text-foreground/90 max-w-2xl">
            {t(ABOUT_NARRATIVE).map((para, i) => (<p key={i}>{para}</p>))}
          </div>
          <div className="mt-10 flex flex-wrap gap-2" data-testid="about-industries">
            {INDUSTRIES.map((i) => (<span key={i} className="text-xs px-3 py-1.5 rounded-full border border-border">{i}</span>))}
          </div>
          <div className="mt-10 flex flex-col sm:flex-row gap-3">
            <Button asChild className="rounded-full px-6" data-testid="about-cta-hire">
              <Link to="/contact">{t(UI.cta.hireExec)} <ArrowUpRight className="h-4 w-4" /></Link>
            </Button>
            <Button asChild variant="outline" className="rounded-full px-6" data-testid="about-cta-work">
              <Link to="/work">{t(UI.cta.allCases)}</Link>
            </Button>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="aspect-[4/5] overflow-hidden rounded-lg border border-border bg-muted">
            <img src={SITE.portrait} alt={`Portrait of ${SITE.name}`} className="h-full w-full object-cover" data-testid="about-portrait" />
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <div className="border-t border-border pt-3">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.sections.aboutHeader.basedIn)}</div>
              <div className="mt-1 font-medium">{t(SITE.location)}</div>
            </div>
            <div className="border-t border-border pt-3">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.sections.aboutHeader.openTo)}</div>
              <div className="mt-1 flex items-center gap-2" data-testid="about-availability">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75 animate-ping" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                <span className="font-medium text-sm">{t(UI.sections.aboutHeader.openValue)}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <section className="mt-24 border-t border-border pt-16">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <div className="eyebrow">{t(UI.sections.aboutHowIWork.eyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl tracking-tight font-medium">{t(UI.sections.aboutHowIWork.heading)}</h2>
          </div>
          <ol className="lg:col-span-8 grid gap-2">
            {PRINCIPLES.map((p) => (
              <li key={p.n} className="grid md:grid-cols-12 gap-6 py-7 border-t border-border">
                <div className="md:col-span-1 text-xs uppercase tracking-[0.18em] text-muted-foreground">{p.n}</div>
                <div className="md:col-span-11">
                  <div className="font-display text-xl sm:text-2xl tracking-tight font-medium">{t(p.h)}</div>
                  <p className="mt-2 text-muted-foreground">{t(p.b)}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mt-24 border-t border-border pt-16" data-testid="core-skills-section">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <div className="eyebrow">{t(UI.sections.coreSkills.eyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl tracking-tight font-medium">{t(UI.sections.coreSkills.heading)}</h2>
            <p className="mt-4 text-muted-foreground max-w-md">{t(UI.sections.coreSkills.sub)}</p>
          </div>
          <div className="lg:col-span-8 grid gap-8">
            {CORE_SKILLS.map((g, gi) => (
              <div key={gi} className="border-t border-border pt-6">
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">{t(g.group)}</div>
                <div className="flex flex-wrap gap-2">
                  {g.items.map((skill) => (
                    <span key={skill} data-testid={`skill-${skill.toLowerCase().replace(/\s/g, "-")}`}
                      className="text-sm px-3 py-1.5 rounded-full border border-border bg-card hover:bg-foreground hover:text-background transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-24 border-t border-border pt-16">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <div className="eyebrow">{t(UI.sections.trajectory.eyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl tracking-tight font-medium">{t(UI.sections.trajectory.heading)}</h2>
          </div>
          <ol className="lg:col-span-8 grid gap-2">
            {TIMELINE.map((tl, i) => (
              <li key={tl.year + i} className="grid md:grid-cols-12 gap-6 py-7 border-t border-border">
                <div className="md:col-span-3 flex md:flex-col gap-3 md:gap-2">
                  <div className="shrink-0 inline-flex h-12 w-12 items-center justify-center rounded-full border border-border bg-card overflow-hidden">
                    {tl.logo ? (
                      <img src={tl.logo} alt="" loading="lazy" className="h-full w-full object-contain p-1.5" />
                    ) : (
                      <span className="text-xs font-mono font-semibold tracking-wider text-muted-foreground">{tl.initials || "—"}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-sm uppercase tracking-[0.18em] text-muted-foreground">{tl.year}</div>
                    {tl.type && (
                      <div className="mt-2 inline-flex items-center text-[11px] font-mono uppercase tracking-wider px-2 py-1 rounded-full border border-border text-muted-foreground">
                        {t(tl.type)}
                      </div>
                    )}
                  </div>
                </div>
                <div className="md:col-span-9">
                  <div className="font-display text-xl tracking-tight font-medium leading-snug">{t(tl.role)}</div>
                  <div className="text-sm text-muted-foreground mt-1">{t(tl.org)}</div>
                  {tl.star && (
                    <ul className="mt-4 grid gap-2">
                      {t(tl.star).map((line, j) => (
                        <li key={j} className="text-sm text-foreground/80 leading-relaxed flex gap-3">
                          <span className="text-muted-foreground select-none mt-1">·</span>
                          <span>{line}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>
    </div>
  );
}
