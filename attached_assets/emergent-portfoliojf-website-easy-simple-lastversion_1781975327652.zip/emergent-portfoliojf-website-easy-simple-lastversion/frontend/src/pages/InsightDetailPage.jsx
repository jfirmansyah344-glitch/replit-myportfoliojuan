import { Link, useParams, Navigate } from "react-router-dom";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { INSIGHTS, UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";
import CommentSection from "@/components/site/CommentSection";

export default function InsightDetailPage() {
  const { t } = useT();
  const { id } = useParams();
  const post = INSIGHTS.find((p) => p.id === id);
  if (!post) return <Navigate to="/insights" replace />;
  const idx = INSIGHTS.findIndex((p) => p.id === id);
  const next = INSIGHTS[(idx + 1) % INSIGHTS.length];

  return (
    <article data-testid={`insight-${post.id}`} className="container-x section-y">
      <Link to="/insights" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground" data-testid="insight-back-link">
        <ArrowLeft className="h-4 w-4" /> {t(UI.cta.backToInsights)}
      </Link>

      <header className="mt-10 max-w-4xl">
        <div className="eyebrow">{t(post.category)} · {post.date} · {t(post.readTime)}</div>
        <h1 className="mt-6 font-display text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-[1] font-medium text-balance">{t(post.title)}</h1>
        <p className="mt-6 text-lg text-muted-foreground leading-relaxed">{t(post.excerpt)}</p>
      </header>

      <div className="mt-12 aspect-[16/8] overflow-hidden rounded-lg border border-border bg-muted">
        <img src={post.cover} alt={t(post.title)} className="h-full w-full object-cover" />
      </div>

      <div className="mt-14 grid lg:grid-cols-12 gap-10 max-w-5xl">
        <div className="lg:col-span-12 prose-content grid gap-6">
          {t(post.body).map((para, i) => (
            <p key={i} className="text-lg lg:text-xl leading-relaxed text-foreground/90">{para}</p>
          ))}
        </div>
      </div>

      {post.youtubeId && (
        <section className="mt-16 max-w-5xl" data-testid="insight-video">
          <div className="eyebrow mb-4">{t(UI.sections.insightsHeader.watchTalk)}</div>
          <div className="aspect-video overflow-hidden rounded-lg border border-border bg-muted">
            <iframe title={t(post.title)} src={`https://www.youtube.com/embed/${post.youtubeId}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen className="h-full w-full" />
          </div>
        </section>
      )}

      <CommentSection postId={post.id} />

      <div className="mt-24 border-t border-border pt-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <Button asChild variant="outline" className="rounded-full" data-testid="insight-cta-contact">
          <Link to="/contact">{t(UI.cta.enrol)} <ArrowUpRight className="h-4 w-4" /></Link>
        </Button>
        <Link to={`/insights/${next.id}`} className="group inline-flex items-center gap-3" data-testid="insight-next-link">
          <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t(UI.cta.nextEssay)}</span>
          <span className="font-display text-xl tracking-tight font-medium link-underline">{t(next.title)}</span>
          <ArrowUpRight className="h-5 w-5 group-hover:rotate-[12deg] transition-transform" />
        </Link>
      </div>
    </article>
  );
}
