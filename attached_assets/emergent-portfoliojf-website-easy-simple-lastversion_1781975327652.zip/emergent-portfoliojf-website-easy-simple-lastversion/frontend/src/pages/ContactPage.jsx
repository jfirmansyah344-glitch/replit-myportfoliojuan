import { Mail, MapPin, Linkedin } from "lucide-react";
import ContactForm from "@/components/site/ContactForm";
import { SITE, UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function ContactPage() {
  const { t } = useT();
  return (
    <div data-testid="contact-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="eyebrow">{t(UI.sections.contactHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.contactHeader.h1)}
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">{t(UI.sections.contactHeader.sub)}</p>
        </div>
      </header>

      <section className="mt-16 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-7"><ContactForm /></div>
        <aside className="lg:col-span-5 grid gap-6 content-start">
          <div className="border border-border rounded-lg p-6">
            <div className="eyebrow mb-3">{t(UI.sections.contactHeader.direct)}</div>
            <div className="grid gap-4 text-sm">
              <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 link-underline" data-testid="contact-email-link">
                <Mail className="h-4 w-4" /> {SITE.email}
              </a>
              <a href="https://www.linkedin.com/in/juanfirmansyah1/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 link-underline" data-testid="contact-linkedin-link">
                <Linkedin className="h-4 w-4" /> linkedin.com/in/juanfirmansyah1
              </a>
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="h-4 w-4" /> {t(SITE.location)}
              </div>
            </div>
          </div>
          <div className="border border-border rounded-lg p-6">
            <div className="eyebrow mb-3">{t(UI.sections.contactHeader.bestFit)}</div>
            <ul className="grid gap-2 text-sm">
              {t(UI.sections.contactHeader.bestFitList).map((line, i) => (<li key={i}>{line}</li>))}
            </ul>
          </div>
        </aside>
      </section>
    </div>
  );
}
