import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { CASE_STUDIES, TIMELINE, UI } from "@/lib/site";
import { useT } from "@/components/site/LanguageProvider";

export default function WorkPage() {
  const { t } = useT();
  return (
    <div data-testid="work-page" className="container-x section-y">
      <header className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="eyebrow">{t(UI.sections.workHeader.eyebrow)}</div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl tracking-tighter leading-[0.95] font-medium text-balance">
            {t(UI.sections.workHeader.h1)}
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">{t(UI.sections.workHeader.sub)}</p>
        </div>
      </header>

      <section className="mt-16 grid gap-6">
        {CASE_STUDIES.map((cs, idx) => (
          <Link key={cs.id} to={`/work/${cs.id}`} data-testid={`work-card-${cs.id}`}
            className="group grid lg:grid-cols-12 gap-8 items-center border border-border rounded-lg p-6 lg:p-8 hover:-translate-y-1 hover:shadow-md transition-all bg-card">
            <div className="lg:col-span-4 aspect-[5/4] overflow-hidden rounded-md bg-muted">
              <img src={cs.cover} alt={t(cs.title)} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="lg:col-span-7">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                {String(idx + 1).padStart(2, "0")} · {t(cs.industry)} · {cs.year}
              </div>
              <h2 className="mt-3 font-display text-2xl sm:text-3xl tracking-tight font-medium">{t(cs.title)}</h2>
              <p className="mt-3 text-muted-foreground max-w-2xl">{t(cs.problem).slice(0, 140)}…</p>
              <div className="mt-5 flex flex-wrap gap-3">
                {cs.results.slice(0, 3).map((r, i) => (
                  <span key={i} className="text-xs px-3 py-1.5 rounded-full border border-border bg-background">
                    <span className="font-medium">{r.metric}</span> <span className="text-muted-foreground">{t(r.label)}</span>
                  </span>
                ))}
              </div>
            </div>
            <div className="lg:col-span-1 flex justify-end">
              <ArrowUpRight className="h-7 w-7 group-hover:rotate-[12deg] transition-transform" />
            </div>
          </Link>
        ))}
      </section>

      <section className="mt-24 border-t border-border pt-16">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <div className="eyebrow">{t(UI.sections.trajectory.eyebrow)}</div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl tracking-tight font-medium">{t(UI.sections.trajectory.heading)}</h2>
          </div>
          <ol className="lg:col-span-8 grid gap-2" data-testid="work-timeline">
            {TIMELINE.map((tl, i) => (
              <li key={tl.year + i} className="grid md:grid-cols-12 gap-6 py-7 border-t border-border">
                <div className="md:col-span-3 flex md:flex-col gap-3 md:gap-2">
                  <div className="shrink-0 inline-flex h-12 w-12 items-center justify-center rounded-full border border-border bg-card overflow-hidden">
                    {tl.logo ? (
                      <img src={tl.logo} alt="" loading="lazy" className="h-full w-full object-contain p-1.5" />
                    ) : (
                      <span className="text-xs font-mono font-semibold tracking-wider text-muted-foreground">{tl.initials || "—"}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-sm uppercase tracking-[0.18em] text-muted-foreground">{tl.year}</div>
                    {tl.type && (
                      <div className="mt-2 inline-flex items-center text-[11px] font-mono uppercase tracking-wider px-2 py-1 rounded-full border border-border text-muted-foreground">
                        {t(tl.type)}
                      </div>
                    )}
                  </div>
                </div>
                <div className="md:col-span-9">
                  <div className="font-display text-xl tracking-tight font-medium leading-snug">{t(tl.role)}</div>
                  <div className="text-sm text-muted-foreground mt-1">{t(tl.org)}</div>
                  {tl.star && (
                    <ul className="mt-4 grid gap-2">
                      {t(tl.star).map((line, j) => (
                        <li key={j} className="text-sm text-foreground/80 leading-relaxed flex gap-3">
                          <span className="text-muted-foreground select-none mt-1">·</span>
                          <span>{line}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>
    </div>
  );
}
