import { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { api, isAdminAuthed, adminLogout } from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import { Check, X, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function AdminCommentsPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState("pending");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async (s = status) => {
    setLoading(true);
    try {
      const q = s && s !== "all" ? `?status=${s}` : "";
      const { data } = await api.get(`/admin/comments${q}`);
      setItems(data);
    } catch (e) {
      if (e?.response?.status === 401) {
        adminLogout();
        navigate("/admin/login");
      } else {
        toast.error("Could not load comments.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(status); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [status]);

  if (!isAdminAuthed()) return <Navigate to="/admin/login" replace />;

  const approve = async (id) => {
    try {
      await api.patch(`/admin/comments/${id}`, { approved: true });
      toast.success("Approved.");
      load(status);
    } catch { toast.error("Failed."); }
  };
  const reject = async (id) => {
    try {
      await api.patch(`/admin/comments/${id}`, { approved: false });
      toast.success("Marked as pending.");
      load(status);
    } catch { toast.error("Failed."); }
  };
  const remove = async (id) => {
    if (!window.confirm("Delete this comment?")) return;
    try {
      await api.delete(`/admin/comments/${id}`);
      toast.success("Deleted.");
      load(status);
    } catch { toast.error("Failed."); }
  };

  const logout = () => {
    adminLogout();
    navigate("/admin/login");
  };

  return (
    <div data-testid="admin-comments-page" className="container-x section-y">
      <div className="flex items-center justify-between">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="mt-3 font-display text-3xl tracking-tight font-medium">Comment moderation</h1>
        </div>
        <Button variant="outline" onClick={logout} className="rounded-full" data-testid="admin-logout-btn">Sign out</Button>
      </div>

      <Tabs value={status} onValueChange={setStatus} className="mt-10">
        <TabsList className="grid grid-cols-3 max-w-md">
          <TabsTrigger value="pending" data-testid="admin-tab-pending">Pending</TabsTrigger>
          <TabsTrigger value="approved" data-testid="admin-tab-approved">Approved</TabsTrigger>
          <TabsTrigger value="all" data-testid="admin-tab-all">All</TabsTrigger>
        </TabsList>

        <TabsContent value={status} className="mt-8">
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : items.length === 0 ? (
            <p className="text-sm text-muted-foreground" data-testid="admin-empty">No comments to show.</p>
          ) : (
            <ul className="grid gap-4">
              {items.map((c) => (
                <li key={c.id} className="border border-border rounded-lg p-5" data-testid={`admin-comment-${c.id}`}>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="font-medium">{c.name} <span className="text-muted-foreground text-sm">· {c.email}</span></div>
                      <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground mt-1">
                        Post: {c.post_id} · {new Date(c.created_at).toLocaleString()} · {c.approved ? "Approved" : "Pending"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!c.approved && (
                        <Button size="sm" onClick={() => approve(c.id)} className="rounded-full" data-testid={`approve-${c.id}`}>
                          <Check className="h-4 w-4" /> Approve
                        </Button>
                      )}
                      {c.approved && (
                        <Button size="sm" variant="outline" onClick={() => reject(c.id)} className="rounded-full" data-testid={`unapprove-${c.id}`}>
                          <X className="h-4 w-4" /> Unapprove
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" onClick={() => remove(c.id)} className="rounded-full" data-testid={`delete-${c.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="mt-4 text-base leading-relaxed">{c.content}</p>
                </li>
              ))}
            </ul>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
